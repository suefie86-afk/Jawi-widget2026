package com.example.jawiclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import java.util.Calendar

class JawiWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(ctx)
        schedule(ctx)
    }

    override fun onEnabled(ctx: Context) = schedule(ctx)

    override fun onDisabled(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pendingTick(ctx))
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                updateAll(ctx)
                schedule(ctx)
            }
        }
    }

    companion object {
        private const val ACTION_TICK = "com.example.jawiclock.TICK"

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, JawiWidget::class.java))
            if (ids.isEmpty()) return
            val now = Calendar.getInstance()
            val rv = RemoteViews(ctx.packageName, R.layout.widget_jawi).apply {
                setTextViewText(R.id.time, Jawi.time(now))
                setTextViewText(R.id.period, Jawi.period(now))
                setTextViewText(R.id.date, Jawi.date(now))
            }
            mgr.updateAppWidget(ids, rv)
        }

        private fun pendingTick(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, JawiWidget::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        // Kejutkan widget pada permulaan setiap minit
        fun schedule(ctx: Context) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val next = Calendar.getInstance().apply {
                add(Calendar.MINUTE, 1)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val pi = pendingTick(ctx)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            }
        }
    }
}
