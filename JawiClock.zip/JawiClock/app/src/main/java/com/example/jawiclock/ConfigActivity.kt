package com.example.jawiclock

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class ConfigActivity : Activity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var style = Style()
    private lateinit var preview: FrameLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val textColors = listOf(
        "#FFFFFF", "#E6C86E", "#A5D6A7", "#90CAF9", "#F48FB1", "#FFB74D", "#000000",
    ).map { Color.parseColor(it) }

    private val bgColors = listOf(
        "#0B3D2E", "#000000", "#1A237E", "#4E342E", "#37474F", "#FFFFFF",
    ).map { Color.parseColor(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)

        widgetId = intent?.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID,
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        style = Prefs.load(this, widgetId)

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1B1B1B"))
        }

        // Pratonton (latar kelabu supaya kesan lutsinar nampak)
        preview = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#3A4252"))
            setPadding(dp(16), dp(24), dp(16), dp(16))
            minimumHeight = dp(190)
        }
        outer.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }

        controls.addView(label("Warna masa & tarikh"))
        controls.addView(swatches(textColors, { style.text }) { style = style.copy(text = it) })

        controls.addView(label("Warna bismillah & waktu"))
        controls.addView(swatches(textColors, { style.accent }) { style = style.copy(accent = it) })

        controls.addView(label("Warna latar"))
        controls.addView(swatches(bgColors, { style.bg }) { style = style.copy(bg = it) })

        controls.addView(
            seek("Kelegapan latar", 100, style.bgAlpha, { if (it == 0) "Lutsinar" else "$it%" }) {
                style = style.copy(bgAlpha = it)
            }
        )
        controls.addView(
            seek("Saiz tulisan", 150, style.scale - 50, { "${it + 50}%" }) {
                style = style.copy(scale = it + 50)
            }
        )

        outer.addView(
            ScrollView(this).apply { addView(controls) },
            LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f),
        )

        val save = Button(this).apply {
            text = "Simpan"
            setOnClickListener {
                Prefs.save(this@ConfigActivity, widgetId, style)
                JawiWidget.updateAll(this@ConfigActivity)
                JawiWidget.schedule(this@ConfigActivity)
                setResult(
                    RESULT_OK,
                    Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId),
                )
                finish()
            }
        }
        outer.addView(save, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
            setMargins(dp(16), dp(8), dp(16), dp(16))
        })

        setContentView(outer)
        refresh()
    }

    private fun refresh() {
        preview.removeAllViews()
        val rv = JawiWidget.build(this, widgetId, style)
        preview.addView(
            rv.apply(this, preview),
            FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.CENTER),
        )
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(Color.parseColor("#DDDDDD"))
        textSize = 14f
        setPadding(0, dp(16), 0, dp(6))
    }

    private fun circle(color: Int, selected: Boolean) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(
            dp(if (selected) 3 else 1),
            if (selected) Color.parseColor("#4FC3F7") else Color.parseColor("#66FFFFFF"),
        )
    }

    private fun swatches(colors: List<Int>, selected: () -> Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = mutableListOf<View>()
        fun paint() {
            colors.forEachIndexed { i, c -> views[i].background = circle(c, c == selected()) }
        }
        colors.forEach { c ->
            val v = View(this)
            v.layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply {
                setMargins(0, 0, dp(10), 0)
            }
            v.setOnClickListener {
                onPick(c)
                paint()
                refresh()
            }
            row.addView(v)
            views += v
        }
        paint()
        return row
    }

    private fun seek(
        title: String,
        max: Int,
        start: Int,
        fmt: (Int) -> String,
        onChange: (Int) -> Unit,
    ): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val t = label("$title: ${fmt(start)}")
        val s = SeekBar(this).apply {
            this.max = max
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    t.text = "$title: ${fmt(p)}"
                    onChange(p)
                    refresh()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        box.addView(t)
        box.addView(s)
        return box
    }
}
